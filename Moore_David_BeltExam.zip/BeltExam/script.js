// Cookies Warning Removal

var accept = document.querySelector('#cookies-btn');

accept.addEventListener('click', ()=>{
    var cookiesWarn = document.querySelector('#relative');
    cookiesWarn.classList.add('disappear');
})

// Cart Alert Message

var cart = document.querySelector('#nav-cart');
cart.addEventListener('click', () => alert('The page says your cart is empty!'));

// Hover On Image
var img1 = document.querySelector('#sec-img');
img1.addEventListener('mouseenter', () => {
img1.setAttribute('src', 'images/assets/succulents-2.jpg');
});
img1.addEventListener('mouseleave', () => {
    img1.setAttribute('src', 'images/assets/succulents-1.jpg');
    });
